# Handoff: Kanban Board (design review)

## Overview
This is a design review artifact for the existing **PLANora** Kanban board (`frontend/src/app/kanban/page.tsx`). It reproduces the current production page as an interactive HTML prototype so the layout, states, and micro-interactions could be reviewed outside the codebase.

## About the Design Files
The file in this bundle (`Planora Kanban.dc.html`) is a **design reference built in HTML** — a working prototype that shows structure, states, and interactions with mock data. It is **not production code to copy directly**. It is a custom in-house component format (loads via `support.js`) that only runs inside the design tool preview — it will not run as-is inside the Next.js app. The task is to **recreate the behavior shown here inside the existing Next.js/React/Tailwind/shadcn codebase**, following its established patterns (the actual `page.tsx`, `AppLayout.tsx`, `lib/api.ts`, `lib/project-utils.ts`, `lib/utils.ts` already implement this — see "Relationship to current code" below).

## Fidelity
**High-fidelity, faithful recreation** — this prototype intentionally mirrors the current production Kanban page pixel-for-pixel (same colors, spacing, type scale, status palette, and copy). No redesign changes were introduced. Use it as a interaction-complete reference for functionality, not as a set of new visuals to implement.

## Relationship to current code
This prototype was built by reading the real source in the attached `frontend/` folder:
- `src/app/kanban/page.tsx` — board layout, card, right detail panel
- `src/components/AppLayout.tsx` — sidebar nav, header, user footer
- `src/lib/project-utils.ts` — status config, late/percent/initials helpers
- `src/lib/api.ts` — status/building/role labels, `ProjectCard` shape
- `src/app/globals.css` — color tokens (sidebar forest-green `oklch(0.115 0.038 148)`, status colors, `--radius`)

Because the prototype is a faithful copy, the fastest path to "build" this is: **no changes needed** to the current implementation unless the review surfaces specific feedback. If feedback does come out of the review, apply it directly to the existing `page.tsx`/`AppLayout.tsx` files rather than porting anything from this HTML bundle.

## Screens / Views
### Kanban board (single view)
- **Layout**: Fixed-height flex row: sidebar (240px, collapsible to 64px) + main column (48px header + flex-1 board/detail row).
- **Sidebar**: forest-green background (`oklch(0.115 0.038 148)`), logo (PLANora wordmark, inverted to white via CSS filter), primary nav (Dashboard, Projektek, Kanban [active], Naptár, Saját feladatok, Előkészítés), divider, secondary nav (Felhasználók, Audit napló, Ütemterv sablon — admin/management only in production), user footer (avatar, name, role, logout).
- **Header**: sidebar toggle, "Kanban tábla" title, "Minden projekt" filter dropdown (non-functional placeholder in prod too), search input (live client-side filter by name/client/settlement), "Új projekt" button.
- **Board**: 5 columns in fixed order — Tervezés alatt (planning), Alapozás (foundation), Szerkezetállítás (structure), Kívülről kész (exterior_done), Kulcsrakész (turnkey). Each column: label + count pill (always emerald-styled regardless of status — matches current prod behavior), divider, card list, "Projekt hozzáadása" affordance.
- **Card**: left border colored by status, project code (uppercase, muted), name, settlement · client, optional "Késik" (late) badge, delivery date + PM initials avatar, progress bar colored by status.
- **Right detail panel** (288px, appears on card click): status + late badges, name/code, client, PM, building type + area, delivery date, progress, "Projekt megnyitása" CTA.

## Interactions & Behavior
- Click a card → toggles the right detail panel (click again or the close icon to dismiss).
- Search input filters cards across all columns in real time (name, client, settlement — case-insensitive).
- "Új projekt" / "Projekt hozzáadása" opens a create-project dialog (name, client, settlement, building type, delivery date, target status); submitting appends a card to the chosen column.
- Sidebar toggle collapses to icon-only rail (matches `group-data-[collapsible=icon]` behavior in the real `Sidebar` component).
- "Projekt megnyitása" in production navigates to `/projects/{id}`; in this prototype it shows a toast placeholder.
- Card and column-add affordances use hover states (translateY + shadow on cards; background tint on nav/buttons).

## State Management
Mirrors the real page's state: `board` (records per status), `search`, `selected` project id (drives right panel), `showNewDialog` + form fields, sidebar collapsed flag. In production this is backed by `api.kanban()`; the prototype uses static mock data instead.

## Design Tokens
- **Font**: Geist (via `next/font/google`), fallback system sans.
- **Neutrals**: slate-50 `#f8fafc`, slate-100 `#f1f5f9`, slate-200 `#e2e8f0`, slate-400 `#94a3b8`, slate-500 `#64748b`, slate-700 `#334155`, slate-900 `#0f172a`.
- **Primary**: blue-600 `#2563eb` / blue-700 `#1d4ed8` (buttons, PM avatars, focus ring).
- **Sidebar**: `oklch(0.115 0.038 148)` bg, `oklch(0.78 0.04 148)` fg, `oklch(0.17 0.04 148)` hover accent, `oklch(0.19 0.04 148)` border.
- **Status colors**: planning sky `#38bdf8`/`#f0f9ff`/`#0369a1`; foundation amber `#fbbf24`/`#fffbeb`/`#b45309`; structure orange `#fb923c`/`#fff7ed`/`#c2410c`; exterior_done teal `#2dd4bf`/`#f0fdfa`/`#0f766e`; turnkey emerald `#10b981`/`#ecfdf5`/`#047857`.
- **Radius**: `--radius: 0.75rem` base (cards ~8px, dialog ~14px, pills full).
- **Card shadow**: `0 1px 2px rgba(15,23,42,0.05)` resting, `0 4px 10px rgba(15,23,42,0.10)` hover; selected card adds a 2px blue ring.

## Assets
- `assets/planora-logo.png`, `assets/planora-icon.png` — copied directly from `frontend/public/`. Use the existing files already in the codebase; no new assets were created.
- Icons: Material Symbols Outlined (used only in this prototype as a stand-in for the app's real icon set — `lucide-react`). Reimplement with the existing `lucide-react` icons already used in `page.tsx`/`AppLayout.tsx` (`Calendar`, `MapPin`, `Package`, `Plus`, `Search`, `X`, `ChevronDown`, `LayoutGrid`, etc.) — do not add a new icon library.

## Files
- `Planora Kanban.dc.html` — the interactive HTML prototype (open with a static server; needs `support.js` alongside it).
- `support.js` — runtime helper the prototype depends on.
- `assets/` — logo/icon images referenced by the prototype (already present in `frontend/public/`).

## Note for the developer
Since this review did not change the design, treat this bundle as **confirmation of current behavior**, not a new spec. If the design review turns up specific change requests, they'll be called out separately — apply those directly to `frontend/src/app/kanban/page.tsx` and related files.
